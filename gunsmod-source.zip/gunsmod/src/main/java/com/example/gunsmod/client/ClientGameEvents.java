package com.example.gunsmod.client;

import com.example.gunsmod.AimPayload;
import com.example.gunsmod.FirePayload;
import com.example.gunsmod.GunItem;
import com.example.gunsmod.GunsMod;
import com.example.gunsmod.ReloadPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = GunsMod.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    private static boolean aiming = false;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            aiming = false;
            return;
        }
        boolean holdingGun = player.getMainHandItem().getItem() instanceof GunItem;
        boolean noScreen = mc.screen == null;

        boolean wantAim = holdingGun && noScreen && ClientModEvents.AIM.isDown();
        if (wantAim != aiming) {
            aiming = wantAim;
            PacketDistributor.sendToServer(new AimPayload(aiming));
        }

        if (holdingGun && noScreen) {
            while (ClientModEvents.RELOAD.consumeClick()) {
                PacketDistributor.sendToServer(new ReloadPayload());
            }
            GunItem gun = (GunItem) player.getMainHandItem().getItem();
            if (gun.type.automatic && mc.options.keyUse.isDown() && !player.isShiftKeyDown()) {
                PacketDistributor.sendToServer(new FirePayload());
            }
        } else {
            while (ClientModEvents.RELOAD.consumeClick()) {
                // discard clicks made while not holding a gun
            }
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        if (!aiming) return;
        if (event.getPlayer().getMainHandItem().getItem() instanceof GunItem gun) {
            event.setNewFovModifier(event.getNewFovModifier() * gun.type.zoom);
        }
    }
}
