package com.example.gunsmod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

public class BotSpawnerItem extends Item {
    private final boolean ally;

    public BotSpawnerItem(Item.Properties props, boolean ally) {
        super(props);
        this.ally = ally;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (!(ctx.getLevel() instanceof ServerLevel level)) {
            return InteractionResult.SUCCESS;
        }
        Player player = ctx.getPlayer();
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());

        GunBotEntity bot = GunsMod.GUN_BOT.get().create(level);
        if (bot == null) return InteractionResult.FAIL;
        bot.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        bot.setAlly(ally);
        if (ally && player != null) {
            bot.setOwner(player.getUUID());
        }
        bot.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.SPAWN_EGG, null);
        bot.setGun(GunType.byIndex(level.random.nextInt(GunType.values().length)));
        level.addFreshEntity(bot);

        if (player != null && !player.isCreative()) {
            ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
