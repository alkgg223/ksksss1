package com.example.gunsmod;

import java.util.EnumSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class GunBotEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> ALLY =
            SynchedEntityData.defineId(GunBotEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> GUN =
            SynchedEntityData.defineId(GunBotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> STAY =
            SynchedEntityData.defineId(GunBotEntity.class, EntityDataSerializers.BOOLEAN);

    /** Bots are a bit weaker than players so they are fair to fight. */
    private static final float BOT_DAMAGE = 0.7f;

    @Nullable
    private UUID ownerUUID;
    private int shootCooldown = 0;
    private int ammoLeft = -1;
    private int reloadTimer = 0;

    public GunBotEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ALLY, true);
        builder.define(GUN, GunType.RIFLE.ordinal());
        builder.define(STAY, false);
    }

    // ------------------------------------------------------------ accessors
    public boolean isAlly() {
        return entityData.get(ALLY);
    }

    public void setAlly(boolean ally) {
        entityData.set(ALLY, ally);
    }

    public GunType getGun() {
        return GunType.byIndex(entityData.get(GUN));
    }

    public void setGun(GunType type) {
        entityData.set(GUN, type.ordinal());
        ammoLeft = type.magSize;
        reloadTimer = 0;
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GunsMod.gunItem(type)));
        setDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    public boolean isStay() {
        return entityData.get(STAY);
    }

    @Nullable
    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public void setOwner(@Nullable UUID uuid) {
        this.ownerUUID = uuid;
    }

    @Nullable
    public Player getOwner() {
        return ownerUUID == null ? null : level().getPlayerByUUID(ownerUUID);
    }

    // ------------------------------------------------------------ AI
    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new BotAttackGoal(this));
        goalSelector.addGoal(2, new BotFollowOwnerGoal(this));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8) {
            @Override
            public boolean canUse() {
                return !(isAlly() && (isStay() || getOwner() != null)) && super.canUse();
            }
        });
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false,
                this::isValidTarget));
    }

    private boolean isValidTarget(LivingEntity t) {
        if (t == this || !t.isAlive()) return false;
        if (t instanceof GunBotEntity b) {
            return b.isAlly() != isAlly(); // allies fight enemy bots
        }
        if (isAlly()) {
            return t instanceof Enemy; // allies shoot hostile mobs
        }
        return t instanceof Player p && !p.isCreative() && !p.isSpectator(); // enemy bots hunt players
    }

    /** Called by the attack goal. */
    public void fireAt(LivingEntity target) {
        if (!(level() instanceof ServerLevel sl)) return;
        GunType t = getGun();
        if (ammoLeft < 0) ammoLeft = t.magSize;
        Vec3 origin = getEyePosition();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.7, 0);
        Vec3 dir = aim.subtract(origin).normalize();
        boolean ally = isAlly();
        UUID owner = ownerUUID;
        GunItem.shoot(sl, this, origin, dir, t, false, BOT_DAMAGE, 1.5f,
                e -> (e instanceof GunBotEntity b && b.isAlly() == ally)
                        || (ally && owner != null && e.getUUID().equals(owner)));
        ammoLeft--;
        shootCooldown = t.fireDelay + (t.automatic ? 2 : 8);
        if (ammoLeft <= 0) {
            reloadTimer = (int) (t.reloadTicks * 0.7f);
        }
    }

    public boolean canShootNow() {
        return shootCooldown <= 0 && reloadTimer <= 0;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (shootCooldown > 0) shootCooldown--;
        if (reloadTimer > 0 && --reloadTimer == 0) {
            ammoLeft = getGun().magSize;
        }
    }

    // ------------------------------------------------------------ interaction
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean isOwner = ownerUUID != null && player.getUUID().equals(ownerUUID);

        if (stack.getItem() instanceof GunItem gi) {
            if (!level().isClientSide) {
                if (isAlly() && ownerUUID != null && !isOwner && !player.isCreative()) {
                    player.displayClientMessage(Component.literal("This bot belongs to someone else"), true);
                    return InteractionResult.CONSUME;
                }
                GunType old = getGun();
                if (gi.type == old) {
                    return InteractionResult.CONSUME;
                }
                setGun(gi.type);
                if (!player.isCreative()) {
                    stack.shrink(1);
                    player.getInventory().placeItemBackInInventory(new ItemStack(GunsMod.gunItem(old)));
                }
                player.displayClientMessage(Component.literal("Bot now holds: " + gi.type.id), true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        if (isAlly() && isOwner && stack.isEmpty() && player.isShiftKeyDown()) {
            if (!level().isClientSide) {
                boolean stay = !isStay();
                entityData.set(STAY, stay);
                player.displayClientMessage(Component.literal(stay ? "Bot: staying here" : "Bot: following you"), true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------ misc
    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (random.nextFloat() < 0.8f) {
            spawnAtLocation(new ItemStack(GunsMod.AMMO.get(), 2 + random.nextInt(6)));
        }
        if (random.nextFloat() < 0.15f) {
            spawnAtLocation(new ItemStack(GunsMod.gunItem(getGun())));
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Ally", isAlly());
        tag.putInt("Gun", entityData.get(GUN));
        tag.putBoolean("Stay", isStay());
        if (ownerUUID != null) tag.putUUID("Owner", ownerUUID);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setAlly(!tag.contains("Ally") || tag.getBoolean("Ally"));
        entityData.set(STAY, tag.getBoolean("Stay"));
        ownerUUID = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        setGun(GunType.byIndex(tag.contains("Gun") ? tag.getInt("Gun") : GunType.RIFLE.ordinal()));
    }

    // ------------------------------------------------------------ goals
    static class BotAttackGoal extends Goal {
        private final GunBotEntity bot;
        private int strafeTime = 0;
        private boolean strafeRight = true;

        BotAttackGoal(GunBotEntity bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = bot.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            bot.getMoveControl().strafe(0, 0);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = bot.getTarget();
            if (target == null) return;
            GunType type = bot.getGun();
            bot.getLookControl().setLookAt(target, 40.0f, 40.0f);

            double dist = bot.distanceTo(target);
            boolean sees = bot.getSensing().hasLineOfSight(target);
            double ideal = Math.min(type.range * 0.5, 20.0);

            if (!sees || dist > ideal) {
                bot.getNavigation().moveTo(target, 1.0);
            } else {
                bot.getNavigation().stop();
                if (--strafeTime <= 0) {
                    strafeTime = 20 + bot.getRandom().nextInt(30);
                    strafeRight = bot.getRandom().nextBoolean();
                }
                float back = dist < ideal * 0.4 ? -0.6f : 0.0f;
                bot.getMoveControl().strafe(back, strafeRight ? 0.5f : -0.5f);
            }

            if (sees && dist <= type.range && bot.canShootNow()) {
                bot.fireAt(target);
            }
        }
    }

    static class BotFollowOwnerGoal extends Goal {
        private final GunBotEntity bot;
        private int recalc = 0;

        BotFollowOwnerGoal(GunBotEntity bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Player owner = bot.getOwner();
            return bot.isAlly() && !bot.isStay() && owner != null && !owner.isSpectator()
                    && bot.getTarget() == null && bot.distanceToSqr(owner) > 6 * 6;
        }

        @Override
        public boolean canContinueToUse() {
            Player owner = bot.getOwner();
            return owner != null && !bot.isStay() && bot.getTarget() == null
                    && bot.distanceToSqr(owner) > 3 * 3;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            Player owner = bot.getOwner();
            if (owner == null) return;
            bot.getLookControl().setLookAt(owner, 10.0f, bot.getMaxHeadXRot());
            if (--recalc > 0) return;
            recalc = 10;
            if (bot.distanceToSqr(owner) > 30 * 30 && owner.onGround()) {
                bot.moveTo(owner.getX() + 1, owner.getY(), owner.getZ() + 1, bot.getYRot(), 0);
                bot.getNavigation().stop();
            } else {
                bot.getNavigation().moveTo(owner, 1.2);
            }
        }
    }
}
