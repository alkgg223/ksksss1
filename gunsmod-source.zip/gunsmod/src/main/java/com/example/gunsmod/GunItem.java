package com.example.gunsmod;

import java.util.function.Predicate;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class GunItem extends Item {
    public final GunType type;

    public GunItem(Item.Properties props, GunType type) {
        super(props.stacksTo(1));
        this.type = type;
    }

    // ---------------------------------------------------------------- state
    public static int getAmmo(ItemStack stack, GunType type) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return tag.contains("Ammo") ? tag.getInt("Ammo") : type.magSize;
    }

    public static void setAmmo(ItemStack stack, int ammo) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("Ammo", ammo));
    }

    public static int getReload(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Reload");
    }

    public static void setReload(ItemStack stack, int ticks) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("Reload", ticks));
    }

    // ---------------------------------------------------------------- use
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResultHolder.pass(stack);
        }
        if (player.isShiftKeyDown()) { // sneak + right click = reload (handy on mobile)
            if (!level.isClientSide) {
                startReload(player, stack);
            }
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            tryFire(level, player, stack);
        }
        return InteractionResultHolder.consume(stack);
    }

    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    public void tryFire(Level level, Player player, ItemStack stack) {
        if (level.isClientSide) return;
        if (player.getCooldowns().isOnCooldown(this)) return;
        if (getReload(stack) > 0) return;
        int ammo = getAmmo(stack, type);
        if (ammo <= 0) {
            player.displayClientMessage(Component.literal("Empty - press R or sneak+right-click to reload")
                    .withStyle(ChatFormatting.RED), true);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8f, 1.2f);
            player.getCooldowns().addCooldown(this, 10);
            return;
        }
        boolean aiming = GunsMod.isAiming(player);
        shoot((ServerLevel) level, player, player.getEyePosition(), player.getLookAngle(),
                type, aiming, 1.0f, 0.0f, ignoreFor(player));
        setAmmo(stack, ammo - 1);
        player.getCooldowns().addCooldown(this, type.fireDelay);
        player.displayClientMessage(Component.literal((ammo - 1) + " / " + type.magSize)
                .withStyle(ChatFormatting.YELLOW), true);
    }

    public static Predicate<Entity> ignoreFor(Player player) {
        return e -> e instanceof GunBotEntity b && b.isAlly() && player.getUUID().equals(b.getOwnerUUID());
    }

    // ---------------------------------------------------------------- shooting (shared with bots)
    public static void shoot(ServerLevel level, LivingEntity shooter, Vec3 origin, Vec3 dir, GunType type,
                             boolean aiming, float dmgMult, float extraSpread, Predicate<Entity> ignore) {
        RandomSource rnd = level.random;
        float spread = type.spread * (aiming ? 0.3f : 1.0f) + extraSpread;

        level.playSound(null, shooter.getX(), shooter.getEyeY(), shooter.getZ(),
                SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.0f,
                type.pitch * (0.95f + rnd.nextFloat() * 0.1f));
        Vec3 muzzle = origin.add(dir.scale(1.0));
        level.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 3, 0.03, 0.03, 0.03, 0.01);

        for (int i = 0; i < type.pellets; i++) {
            double f = spread * 0.0175;
            Vec3 d = dir.add(rnd.nextGaussian() * f, rnd.nextGaussian() * f, rnd.nextGaussian() * f).normalize();
            Vec3 end = origin.add(d.scale(type.range));

            BlockHitResult bhr = level.clip(new ClipContext(origin, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
            Vec3 stop = bhr.getType() == HitResult.Type.MISS ? end : bhr.getLocation();

            AABB box = new AABB(origin, stop).inflate(1.0);
            EntityHitResult ehr = ProjectileUtil.getEntityHitResult(level, shooter, origin, stop, box,
                    e -> e.isAlive() && !e.isSpectator() && e.isPickable() && e != shooter && !ignore.test(e));

            Vec3 impact = stop;
            if (ehr != null) {
                impact = ehr.getLocation();
                Entity target = ehr.getEntity();
                float dmg = type.damage * dmgMult;
                boolean head = target instanceof LivingEntity le && impact.y >= le.getEyeY() - 0.15;
                if (head) dmg *= 1.5f;
                DamageSource src = shooter instanceof Player p
                        ? level.damageSources().playerAttack(p)
                        : level.damageSources().mobAttack(shooter);
                target.invulnerableTime = 0;
                target.hurt(src, dmg);
                if (shooter instanceof ServerPlayer sp) {
                    sp.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.6f, head ? 2.0f : 1.4f);
                }
            } else if (bhr.getType() != HitResult.Type.MISS) {
                BlockState bs = level.getBlockState(bhr.getBlockPos());
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, bs),
                        impact.x, impact.y, impact.z, 6, 0.05, 0.05, 0.05, 0.1);
            }

            double dist = origin.distanceTo(impact);
            double step = type.pellets > 1 ? 3.0 : 2.0;
            for (double t = 2.0; t < dist; t += step) {
                Vec3 p = origin.add(d.scale(t));
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }
    }

    // ---------------------------------------------------------------- reload
    public static void startReload(Player player, ItemStack stack) {
        if (!(stack.getItem() instanceof GunItem gun)) return;
        GunType type = gun.type;
        if (getReload(stack) > 0) return;
        if (getAmmo(stack, type) >= type.magSize) return;
        if (!player.getAbilities().instabuild && countAmmo(player) <= 0) {
            player.displayClientMessage(Component.literal("No ammo!").withStyle(ChatFormatting.RED), true);
            return;
        }
        setReload(stack, type.reloadTicks);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 0.8f, 1.4f);
        player.displayClientMessage(Component.literal("Reloading...").withStyle(ChatFormatting.GRAY), true);
    }

    private static int countAmmo(Player player) {
        int n = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(GunsMod.AMMO.get())) n += s.getCount();
        }
        return n;
    }

    private static int takeAmmo(Player player, int wanted) {
        int taken = 0;
        for (int i = 0; i < player.getInventory().getContainerSize() && taken < wanted; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(GunsMod.AMMO.get())) {
                int t = Math.min(s.getCount(), wanted - taken);
                s.shrink(t);
                taken += t;
            }
        }
        return taken;
    }

    private void finishReload(Player player, ItemStack stack) {
        int current = getAmmo(stack, type);
        int need = type.magSize - current;
        int got = player.getAbilities().instabuild ? need : takeAmmo(player, need);
        setAmmo(stack, current + got);
        setReload(stack, 0);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 0.8f, 1.6f);
        player.displayClientMessage(Component.literal((current + got) + " / " + type.magSize)
                .withStyle(ChatFormatting.GREEN), true);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player)) return;
        int r = getReload(stack);
        if (r > 0) {
            if (!selected) {
                setReload(stack, 0); // switched weapon: reload cancelled
            } else if (r - 1 <= 0) {
                finishReload(player, stack);
            } else {
                setReload(stack, r - 1);
            }
        }
        if (selected && GunsMod.isAiming(player)) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 0, false, false, false));
        }
    }
}
