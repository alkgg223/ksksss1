package com.example.gunsmod.client;

import com.example.gunsmod.GunsMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = GunsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping RELOAD = new KeyMapping("key.gunsmod.reload",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.gunsmod");
    public static final KeyMapping AIM = new KeyMapping("key.gunsmod.aim",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.gunsmod");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(RELOAD);
        event.register(AIM);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GunsMod.GUN_BOT.get(), GunBotRenderer::new);
    }
}
