package com.example.gunsmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Sent every tick by the client while holding right-click with an automatic gun. */
public record FirePayload() implements CustomPacketPayload {
    public static final Type<FirePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "fire"));
    public static final StreamCodec<ByteBuf, FirePayload> CODEC = StreamCodec.unit(new FirePayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
