package com.example.gunsmod.client;

import com.example.gunsmod.GunBotEntity;
import com.example.gunsmod.GunsMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GunBotRenderer extends HumanoidMobRenderer<GunBotEntity, HumanoidModel<GunBotEntity>> {
    private static final ResourceLocation ALLY_TEX =
            ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "textures/entity/bot_ally.png");
    private static final ResourceLocation ENEMY_TEX =
            ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "textures/entity/bot_enemy.png");

    public GunBotRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(GunBotEntity bot) {
        return bot.isAlly() ? ALLY_TEX : ENEMY_TEX;
    }

    @Override
    public void render(GunBotEntity bot, float yaw, float partialTicks, PoseStack stack,
                       MultiBufferSource buffer, int light) {
        // hold the gun with both arms raised, like a crossbow
        model.rightArmPose = HumanoidModel.ArmPose.CROSSBOW_HOLD;
        model.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        super.render(bot, yaw, partialTicks, stack, buffer, light);
    }
}
