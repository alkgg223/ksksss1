package com.example.gunsmod;

public enum GunType {
    //        id        dmg   mag delay reload spread pellets range auto   zoom  pitch
    PISTOL ("pistol",  5.0f, 12,  8,  40, 1.5f, 1,  64, false, 0.85f, 1.6f),
    SMG    ("smg",     3.0f, 30,  2,  50, 3.5f, 1,  48, true,  0.85f, 1.9f),
    RIFLE  ("rifle",   4.5f, 30,  3,  60, 2.0f, 1,  96, true,  0.70f, 1.3f),
    SHOTGUN("shotgun", 2.5f,  6, 20,  70, 7.0f, 8,  24, false, 0.85f, 0.8f),
    SNIPER ("sniper", 20.0f,  5, 40,  80, 0.2f, 1, 160, false, 0.25f, 0.6f);

    public final String id;
    public final float damage;
    public final int magSize;
    public final int fireDelay;
    public final int reloadTicks;
    public final float spread;
    public final int pellets;
    public final double range;
    public final boolean automatic;
    public final float zoom;
    public final float pitch;

    GunType(String id, float damage, int magSize, int fireDelay, int reloadTicks, float spread,
            int pellets, double range, boolean automatic, float zoom, float pitch) {
        this.id = id;
        this.damage = damage;
        this.magSize = magSize;
        this.fireDelay = fireDelay;
        this.reloadTicks = reloadTicks;
        this.spread = spread;
        this.pellets = pellets;
        this.range = range;
        this.automatic = automatic;
        this.zoom = zoom;
        this.pitch = pitch;
    }

    public static GunType byIndex(int i) {
        GunType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
