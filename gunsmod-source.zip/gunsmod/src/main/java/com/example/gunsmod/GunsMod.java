package com.example.gunsmod;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(GunsMod.MODID)
public class GunsMod {
    public static final String MODID = "gunsmod";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredItem<Item> AMMO = ITEMS.registerItem("ammo", Item::new);

    public static final DeferredItem<GunItem> PISTOL = ITEMS.registerItem("pistol", p -> new GunItem(p, GunType.PISTOL));
    public static final DeferredItem<GunItem> SMG = ITEMS.registerItem("smg", p -> new GunItem(p, GunType.SMG));
    public static final DeferredItem<GunItem> RIFLE = ITEMS.registerItem("rifle", p -> new GunItem(p, GunType.RIFLE));
    public static final DeferredItem<GunItem> SHOTGUN = ITEMS.registerItem("shotgun", p -> new GunItem(p, GunType.SHOTGUN));
    public static final DeferredItem<GunItem> SNIPER = ITEMS.registerItem("sniper", p -> new GunItem(p, GunType.SNIPER));

    public static final DeferredItem<BotSpawnerItem> ALLY_SPAWNER =
            ITEMS.registerItem("ally_bot_spawner", p -> new BotSpawnerItem(p, true));
    public static final DeferredItem<BotSpawnerItem> ENEMY_SPAWNER =
            ITEMS.registerItem("enemy_bot_spawner", p -> new BotSpawnerItem(p, false));

    public static final DeferredHolder<EntityType<?>, EntityType<GunBotEntity>> GUN_BOT =
            ENTITIES.register("gun_bot", () -> EntityType.Builder.of(GunBotEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.8f).clientTrackingRange(10).build("gun_bot"));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.gunsmod"))
                    .icon(() -> new ItemStack(RIFLE.get()))
                    .displayItems((params, output) -> ITEMS.getEntries().forEach(h -> output.accept(h.get())))
                    .build());

    /** Players currently aiming (server side). */
    public static final Set<UUID> AIMING = ConcurrentHashMap.newKeySet();

    public static boolean isAiming(Player player) {
        return AIMING.contains(player.getUUID());
    }

    public static Item gunItem(GunType type) {
        return switch (type) {
            case PISTOL -> PISTOL.get();
            case SMG -> SMG.get();
            case RIFLE -> RIFLE.get();
            case SHOTGUN -> SHOTGUN.get();
            case SNIPER -> SNIPER.get();
        };
    }

    public GunsMod(IEventBus modBus) {
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(this::registerPayloads);
        modBus.addListener(this::registerAttributes);
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> AIMING.remove(e.getEntity().getUUID()));
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(GUN_BOT.get(), GunBotEntity.createAttributes().build());
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar reg = event.registrar("1");
        reg.playToServer(ReloadPayload.TYPE, ReloadPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                ItemStack s = sp.getMainHandItem();
                if (s.getItem() instanceof GunItem) {
                    GunItem.startReload(sp, s);
                }
            }
        }));
        reg.playToServer(FirePayload.TYPE, FirePayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                ItemStack s = sp.getMainHandItem();
                if (s.getItem() instanceof GunItem g && g.type.automatic) {
                    g.tryFire(sp.level(), sp, s);
                }
            }
        }));
        reg.playToServer(AimPayload.TYPE, AimPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                if (payload.aiming()) {
                    AIMING.add(sp.getUUID());
                } else {
                    AIMING.remove(sp.getUUID());
                }
            }
        }));
    }
}
