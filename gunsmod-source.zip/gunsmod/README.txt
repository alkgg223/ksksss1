Guns and Bots - NeoForge 1.21.1 (21.1.264)

BUILD (needs JDK 21 + internet, one time):
  1) Install JDK 21 and Gradle 8.10 or newer  (or open this folder in IntelliJ IDEA as a Gradle project)
  2) In this folder run:   gradle build
  3) The mod jar is at:    build/libs/gunsmod-1.0.0.jar   -> copy it into your .minecraft/mods folder

CONTROLS
  Right click ........ shoot (hold for automatic guns: SMG, Rifle)
  R .................. reload (uses Ammo items; free in creative)
  Sneak + right click  reload (for touch / no keyboard)
  Z (hold) ........... aim: zoom, less spread, slower walking
  Right click a bot with a gun .. gives it that gun (swaps with its old one)
  Sneak + empty hand on your ally bot .. toggle follow / stay

ITEMS (creative tab "Guns and Bots")
  Pistol, SMG, Assault Rifle, Shotgun, Sniper, Ammo, Ally Bot Spawner, Enemy Bot Spawner
  Ammo + guns are craftable in survival. Bot spawners are creative-only.
